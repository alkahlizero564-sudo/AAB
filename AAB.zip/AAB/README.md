# AAB — توصيات فوركس • ذهب • أسهم • كريبتو (Flutter)

## الرفع على GitHub (مستودع AAB)
```
git init && git add . && git commit -m "AAB app"
git branch -M main
git remote add origin https://github.com/<USERNAME>/AAB.git
git push -u origin main
```
بعد الرفع يعمل GitHub Actions تلقائياً (تبويب Actions) ويبني APK و AAB.
حمّل الملفات من Artifacts باسم `AAB-release`.

## التشغيل محلياً
```
flutter create --platforms=android --org com.aab --project-name aab .
# (أعد ملفات lib و pubspec.yaml إن استبدلها الأمر)
# أضف في android/app/src/main/AndroidManifest.xml قبل <application>:
#   <uses-permission android:name="android.permission.INTERNET"/>
flutter pub get && flutter run
```

## المفاتيح (من شاشة الإعدادات)
- Tiingo: حقل واحد • Twelve Data: 4 حقول • Gemini: 4 حقول
